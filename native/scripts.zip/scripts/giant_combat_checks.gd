extends RefCounted

# Exercise actual combat at the giant collider's edge, not inside its centre.
static func run(g,boss) -> Dictionary:
	var checks={};var saved_stats=g.stats.duplicate(true);var saved_position=g.player.position
	g.stats=g.rules.data.stats.duplicate(true);g.hp=g.stats.maxHp;g.invulnerable=999
	boss.freeze=999;boss.attack=999;boss.contact=999
	var edge=boss.node.position+Vector3(10,1,0)
	g.player.position=edge
	checks.giant_collider_contact=g.melee_contact(boss,edge).distance_to(boss.node.position+Vector3(9,1,0))<.01
	var hp=boss.hp
	g.damage_area(edge,3,17,"slam")
	checks.giant_slam_edge=is_equal_approx(hp-boss.hp,17)
	hp=boss.hp
	g.damage_area(boss.node.position+Vector3(14,1,0),3,17,"slam")
	g.damage_area(boss.node.position+Vector3.UP*46,3,17,"slam")
	checks.giant_area_outside_bounds=is_equal_approx(hp,boss.hp)
	var horn=g.rules.data.weapons.filter(func(w):return w.id=="horn")[0].duplicate(true)
	horn.kind="weapon";horn.strength=1;horn.tier=0;g.equip_weapon(horn)
	hp=boss.hp;g.fire(g.equipped[-1],edge)
	checks.giant_horn_edge=boss.hp<hp
	g.equipped.clear()
	var flowers=g.rules.data.weapons.filter(func(w):return w.id=="flowers")[0].duplicate(true)
	flowers.kind="weapon";flowers.strength=1;flowers.tier=0;g.equip_weapon(flowers)
	g.stats.flowerPollen=7;g.stats.flowerRoots=.2
	g.plant_flower(edge-Vector3.UP,g.equipped[-1]);g.flowers[-1].age=2
	hp=boss.hp;g.update_garden(.1)
	checks.giant_flower_bloom=boss.hp<hp
	checks.giant_flower_status=boss.poison>=7 and boss.slow>=.2
	g.equipped.clear();g.update_garden(0)
	boss.poison=0;boss.fire=0;boss.status_time=0;boss.slow=0
	g.stats.auraDamage=20;hp=boss.hp;g.update_combat(.1)
	checks.giant_aura_edge=boss.hp<hp and g.has_meta("aura_node")
	g.stats.auraDamage=0;g.update_aura_visual()
	# The same body-distance query must follow wall/ceiling orientation.
	var rotation=boss.node.rotation;boss.node.rotation=Vector3(0,0,PI*.5)
	var side=boss.node.position+Vector3(-20,10,0)
	checks.rotated_collider_contact=g.melee_contact(boss,side).distance_to(boss.node.position+Vector3(-20,9,0))<.01
	boss.node.rotation=rotation
	g.stats=saved_stats;g.hp=g.stats.maxHp;g.player.position=saved_position
	g.avatar.sync_equipment(g.equipped)
	return checks
